package com.example.camera;

public class Barcode {
    private Product product;


    public Barcode(Product product){
        this.product=product;

    }
    public Barcode() {

    }
    public Product getProduct(){

        return product;
    }


}
